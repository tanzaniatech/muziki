<div class="footer">
<div class="container">
<p class="copy">Copyright &copy; <?php echo date( 'Y' ); ?> | <a href="<?php echo site_url(); ?>"><?php echo get_option( 'site_name' ); ?></a></p>
<div class="clearfix"></div>
</div>
</div> 	
</body>	

</html>